# Como instalar

Abrir um terminal e digitar
```
npm install
```

# Como executar

Abrir um terminal e digitar
```
npm run dev
```